<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* bezoeker/kartactiviteiten.html.twig */
class __TwigTemplate_78754f77b64b6dda46295a027a274e76 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'menu' => [$this, 'block_menu'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "bezoeker.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bezoeker/kartactiviteiten.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bezoeker/kartactiviteiten.html.twig"));

        $this->parent = $this->loadTemplate("bezoeker.html.twig", "bezoeker/kartactiviteiten.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 2
    public function block_menu($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        // line 3
        echo "    <li><a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("homepage");
        echo "\">home</a></li>
    <li class=\"active\"><a href=\"";
        // line 4
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("kartactiviteiten");
        echo "\">aanbod</a></li>
    <li><a href=\"";
        // line 5
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("registreren");
        echo "\">registreren</a></li>
    <li><a href=\"#\">contact</a></li>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 9
        echo "    <section >
        <article>
            <h3>Er zijn ";
        // line 11
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["soortactiviteiten"]) || array_key_exists("soortactiviteiten", $context) ? $context["soortactiviteiten"] : (function () { throw new RuntimeError('Variable "soortactiviteiten" does not exist.', 11, $this->source); })())), "html", null, true);
        echo " soorten activiteiten </h3>
            <ul class=\"list-group\">
                ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["soortactiviteiten"]) || array_key_exists("soortactiviteiten", $context) ? $context["soortactiviteiten"] : (function () { throw new RuntimeError('Variable "soortactiviteiten" does not exist.', 13, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["activiteit"]) {
            // line 14
            echo "                <li class=\"list-group-item text-primary\">naam: ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "naam", [], "any", false, false, false, 14), "html", null, true);
            echo "  prijs: ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "prijs", [], "any", false, false, false, 14), "html", null, true);
            echo " tijdsduur: ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "tijdsduur", [], "any", false, false, false, 14), "html", null, true);
            echo " minleeftijd: ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "minleeftijd", [], "any", false, false, false, 14), "html", null, true);
            echo " </li>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['activiteit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "            </ul>
            <p>
                Let op, voor het karten zijn dichte schoenen verplicht.
                Karten met een korte broek is niet toegestaan. Wij hebben overalls ter beschikking,
                maar probeer indien mogelijk een lange broek aan te doen of mee te nemen.
            </p>
        </article>
        <figure>
            <img class=\"img-responsive center-block\" style=\"width:30%\"src=";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/kart.jpg"), "html", null, true);
        echo " alt=\"kart\" />
        </figure>
    </section>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "bezoeker/kartactiviteiten.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 24,  129 => 16,  114 => 14,  110 => 13,  105 => 11,  101 => 9,  91 => 8,  78 => 5,  74 => 4,  69 => 3,  59 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'bezoeker.html.twig' %}
{% block menu %}
    <li><a href=\"{{ path('homepage') }}\">home</a></li>
    <li class=\"active\"><a href=\"{{ path('kartactiviteiten') }}\">aanbod</a></li>
    <li><a href=\"{{ path('registreren') }}\">registreren</a></li>
    <li><a href=\"#\">contact</a></li>
{% endblock %}
{% block content %}
    <section >
        <article>
            <h3>Er zijn {{ soortactiviteiten|length }} soorten activiteiten </h3>
            <ul class=\"list-group\">
                {% for activiteit in soortactiviteiten %}
                <li class=\"list-group-item text-primary\">naam: {{ activiteit.naam }}  prijs: {{ activiteit.prijs }} tijdsduur: {{ activiteit.tijdsduur }} minleeftijd: {{ activiteit.minleeftijd }} </li>
                {% endfor %}
            </ul>
            <p>
                Let op, voor het karten zijn dichte schoenen verplicht.
                Karten met een korte broek is niet toegestaan. Wij hebben overalls ter beschikking,
                maar probeer indien mogelijk een lange broek aan te doen of mee te nemen.
            </p>
        </article>
        <figure>
            <img class=\"img-responsive center-block\" style=\"width:30%\"src={{ asset('img/kart.jpg') }} alt=\"kart\" />
        </figure>
    </section>
{% endblock %}", "bezoeker/kartactiviteiten.html.twig", "C:\\xampp\\htdocs\\karting4\\templates\\bezoeker\\kartactiviteiten.html.twig");
    }
}
