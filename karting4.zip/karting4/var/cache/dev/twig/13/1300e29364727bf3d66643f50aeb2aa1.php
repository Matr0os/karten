<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* deelnemer/activiteiten.html.twig */
class __TwigTemplate_695002cdb63360e00b818f6afcc39703 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'menu' => [$this, 'block_menu'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "deelnemer.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "deelnemer/activiteiten.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "deelnemer/activiteiten.html.twig"));

        $this->parent = $this->loadTemplate("deelnemer.html.twig", "deelnemer/activiteiten.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 2
    public function block_menu($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        // line 3
        echo "    <li><a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("activiteiten");
        echo "\">home</a></li>


";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 9
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 10
        echo "<section >
    <table class=\"table\" style=\"table-layout: fixed\" >
        <caption>
            Dit zijn alle beschikbare activiteiten
        </caption>
        <thead>
        <tr>
            <td>datum</td>
            <td>tijd</td>
            <td>soort activiteit</td>
            <td>prijs</td>
            <td>schrijf in</td>
        </tr>
        </thead>
        <tbody>
        ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["beschikbare_activiteiten"]) || array_key_exists("beschikbare_activiteiten", $context) ? $context["beschikbare_activiteiten"] : (function () { throw new RuntimeError('Variable "beschikbare_activiteiten" does not exist.', 25, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["activiteit"]) {
            // line 26
            echo "        <tr>
            <td>
                ";
            // line 28
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "datum", [], "any", false, false, false, 28), "d-m-Y"), "html", null, true);
            echo "
            </td>
            <td>
                ";
            // line 31
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "tijd", [], "any", false, false, false, 31), "H:i"), "html", null, true);
            echo "
            </td>

            <td>
                ";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["activiteit"], "soort", [], "any", false, false, false, 35), "naam", [], "any", false, false, false, 35), "html", null, true);
            echo "
            </td>
            <td>
                &euro;";
            // line 38
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["activiteit"], "soort", [], "any", false, false, false, 38), "prijs", [], "any", false, false, false, 38), 2, ",", "."), "html", null, true);
            echo "
            </td>
            <td title=\"schrijf in voor activiteit\">


                <a href=\"";
            // line 43
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("inschrijven", ["id" => twig_get_attribute($this->env, $this->source, $context["activiteit"], "id", [], "any", false, false, false, 43)]), "html", null, true);
            echo "\" >
                    <span class=\"glyphicon glyphicon-plus\" style=\"color:red\"></span>
                </a>
            </td>
        </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['activiteit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "        </tbody>
    </table>

    <table class=\"table\" style=\"table-layout: fixed\">
        <caption>
            Dit zijn de door jou ingeschreven activiteiten
        </caption>
        <thead>
        <tr>
            <td>datum</td>
            <td>tijd</td>
            <td>soort activiteit</td>
            <td>prijs</td>
            <td>schrijf uit</td>
        </tr>
        </thead>
        <tbody>
        ";
        // line 66
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ingeschreven_activiteiten"]) || array_key_exists("ingeschreven_activiteiten", $context) ? $context["ingeschreven_activiteiten"] : (function () { throw new RuntimeError('Variable "ingeschreven_activiteiten" does not exist.', 66, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["activiteit"]) {
            // line 67
            echo "            <tr>
                <td>
                    ";
            // line 69
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "datum", [], "any", false, false, false, 69), "d-m-Y"), "html", null, true);
            echo "
                </td>
                <td>
                    ";
            // line 72
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "tijd", [], "any", false, false, false, 72), "H:i"), "html", null, true);
            echo "
                </td>

                <td>
                    ";
            // line 76
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["activiteit"], "soort", [], "any", false, false, false, 76), "naam", [], "any", false, false, false, 76), "html", null, true);
            echo "
                </td>
                <td>
                    &euro;";
            // line 79
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["activiteit"], "soort", [], "any", false, false, false, 79), "prijs", [], "any", false, false, false, 79), 2, ",", "."), "html", null, true);
            echo "
                </td>
                <td title=\"schrijf in voor activiteit\">
                    <a href=\"";
            // line 82
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("uitschrijven", ["id" => twig_get_attribute($this->env, $this->source, $context["activiteit"], "id", [], "any", false, false, false, 82)]), "html", null, true);
            echo "\" >
                        <span class=\"glyphicon glyphicon-minus\" style=\"color:red\"></span>
                    </a>
                </td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['activiteit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 89
        echo "        <tr>
            <td>
            </td>
            <td>
            </td>
            <td>
                Totaal prijs:
            </td>
            <td>
                &euro;";
        // line 98
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (isset($context["totaal"]) || array_key_exists("totaal", $context) ? $context["totaal"] : (function () { throw new RuntimeError('Variable "totaal" does not exist.', 98, $this->source); })()), 2, ",", "."), "html", null, true);
        echo "

            </td>
            <td>
            </td>
        </tr>

        </tbody>
    </table>
</section>


";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "deelnemer/activiteiten.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  234 => 98,  223 => 89,  210 => 82,  204 => 79,  198 => 76,  191 => 72,  185 => 69,  181 => 67,  177 => 66,  158 => 49,  146 => 43,  138 => 38,  132 => 35,  125 => 31,  119 => 28,  115 => 26,  111 => 25,  94 => 10,  84 => 9,  69 => 3,  59 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'deelnemer.html.twig' %}
{% block menu %}
    <li><a href=\"{{ path('activiteiten') }}\">home</a></li>


{% endblock %}


{% block content %}
<section >
    <table class=\"table\" style=\"table-layout: fixed\" >
        <caption>
            Dit zijn alle beschikbare activiteiten
        </caption>
        <thead>
        <tr>
            <td>datum</td>
            <td>tijd</td>
            <td>soort activiteit</td>
            <td>prijs</td>
            <td>schrijf in</td>
        </tr>
        </thead>
        <tbody>
        {% for activiteit in beschikbare_activiteiten %}
        <tr>
            <td>
                {{ activiteit.datum|date(\"d-m-Y\")}}
            </td>
            <td>
                {{ activiteit.tijd|date(\"H:i\")}}
            </td>

            <td>
                {{ activiteit.soort.naam}}
            </td>
            <td>
                &euro;{{ activiteit.soort.prijs|number_format(2,',','.')}}
            </td>
            <td title=\"schrijf in voor activiteit\">


                <a href=\"{{ path('inschrijven', {'id':activiteit.id}) }}\" >
                    <span class=\"glyphicon glyphicon-plus\" style=\"color:red\"></span>
                </a>
            </td>
        </tr>
        {% endfor %}
        </tbody>
    </table>

    <table class=\"table\" style=\"table-layout: fixed\">
        <caption>
            Dit zijn de door jou ingeschreven activiteiten
        </caption>
        <thead>
        <tr>
            <td>datum</td>
            <td>tijd</td>
            <td>soort activiteit</td>
            <td>prijs</td>
            <td>schrijf uit</td>
        </tr>
        </thead>
        <tbody>
        {% for activiteit in ingeschreven_activiteiten %}
            <tr>
                <td>
                    {{ activiteit.datum|date(\"d-m-Y\")}}
                </td>
                <td>
                    {{ activiteit.tijd|date(\"H:i\")}}
                </td>

                <td>
                    {{ activiteit.soort.naam}}
                </td>
                <td>
                    &euro;{{ activiteit.soort.prijs|number_format(2,',','.')}}
                </td>
                <td title=\"schrijf in voor activiteit\">
                    <a href=\"{{ path('uitschrijven', {'id':activiteit.id}) }}\" >
                        <span class=\"glyphicon glyphicon-minus\" style=\"color:red\"></span>
                    </a>
                </td>

            </tr>
        {% endfor %}
        <tr>
            <td>
            </td>
            <td>
            </td>
            <td>
                Totaal prijs:
            </td>
            <td>
                &euro;{{totaal|number_format(2,',','.')}}

            </td>
            <td>
            </td>
        </tr>

        </tbody>
    </table>
</section>


{% endblock %}
", "deelnemer/activiteiten.html.twig", "C:\\xampp\\htdocs\\karting4\\templates\\deelnemer\\activiteiten.html.twig");
    }
}
