<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* medewerker/beheer.html.twig */
class __TwigTemplate_5de8e67cbb71d97bbf680bc6bd58bdeb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'menu' => [$this, 'block_menu'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "medewerker.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "medewerker/beheer.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "medewerker/beheer.html.twig"));

        $this->parent = $this->loadTemplate("medewerker.html.twig", "medewerker/beheer.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_menu($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        // line 4
        echo "    <li><a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("activiteitenoverzicht");
        echo "\">home</a></li>
    <li class=\"active\"><a href=\"";
        // line 5
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("beheer");
        echo "\"><span class=\"badge\">";
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["activiteiten"]) || array_key_exists("activiteiten", $context) ? $context["activiteiten"] : (function () { throw new RuntimeError('Variable "activiteiten" does not exist.', 5, $this->source); })())), "html", null, true);
        echo "</span>beheer</a></li>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 8
        echo "    <section >
        <table class=\"table\" style=\"table-layout: fixed\">
            <caption>Dit zijn alle activiteiten van het kartcentrum</caption>
            <thead>
            <tr>
                <td>datum</td>
                <td>Tijd</td>
                <td>soort activiteit</td>
                <td>deelnemers</td>
                <td>bewerken</td>
                <td>verwijderen</td>
            </tr>
            </thead>
            <tbody>
            ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["activiteiten"]) || array_key_exists("activiteiten", $context) ? $context["activiteiten"] : (function () { throw new RuntimeError('Variable "activiteiten" does not exist.', 22, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["activiteit"]) {
            // line 23
            echo "                <tr>
                    <td>
                        ";
            // line 25
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "datum", [], "any", false, false, false, 25), "d-m-Y"), "html", null, true);
            echo "
                    </td>
                    <td>
                        ";
            // line 28
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "tijd", [], "any", false, false, false, 28), "H:i"), "html", null, true);
            echo "
                    </td>

                    <td>
                        ";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["activiteit"], "soort", [], "any", false, false, false, 32), "naam", [], "any", false, false, false, 32), "html", null, true);
            echo "
                    </td>
                    <td>
                        ";
            // line 35
            echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteit"], "users", [], "any", false, false, false, 35)), "html", null, true);
            echo "
                    </td>
                    <td title=\"bewerk de gegevens van deze activiteit\">


                        <a href=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("update", ["id" => twig_get_attribute($this->env, $this->source, $context["activiteit"], "id", [], "any", false, false, false, 40)]), "html", null, true);
            echo "\" >
                            <span class=\"glyphicon glyphicon-pencil\" style=\"color:red\"></span>
                        </a>
                    </td>
                    <td title=\"verwijder deze activiteit is definitief\">
                        <a href=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete", ["id" => twig_get_attribute($this->env, $this->source, $context["activiteit"], "id", [], "any", false, false, false, 45)]), "html", null, true);
            echo "\" >
                            <span class=\"glyphicon glyphicon-minus\" style=\"color:red\"></span>
                        </a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['activiteit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "            <tr>
                <td colspan=\"6\">
                    <a href=\"";
        // line 53
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("add");
        echo "\">
                        <span class=\"glyphicon glyphicon-plus\" style=\"color:red\"></span>
                    </a>
                </td>

            </tr>

            </tbody>

        </table>


    </section>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "medewerker/beheer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  173 => 53,  169 => 51,  157 => 45,  149 => 40,  141 => 35,  135 => 32,  128 => 28,  122 => 25,  118 => 23,  114 => 22,  98 => 8,  88 => 7,  74 => 5,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'medewerker.html.twig' %}

{% block menu %}
    <li><a href=\"{{ path('activiteitenoverzicht') }}\">home</a></li>
    <li class=\"active\"><a href=\"{{ path('beheer') }}\"><span class=\"badge\">{{ activiteiten|length }}</span>beheer</a></li>
{% endblock %}
{% block content %}
    <section >
        <table class=\"table\" style=\"table-layout: fixed\">
            <caption>Dit zijn alle activiteiten van het kartcentrum</caption>
            <thead>
            <tr>
                <td>datum</td>
                <td>Tijd</td>
                <td>soort activiteit</td>
                <td>deelnemers</td>
                <td>bewerken</td>
                <td>verwijderen</td>
            </tr>
            </thead>
            <tbody>
            {% for activiteit in activiteiten %}
                <tr>
                    <td>
                        {{ activiteit.datum|date(\"d-m-Y\")}}
                    </td>
                    <td>
                        {{ activiteit.tijd|date(\"H:i\")}}
                    </td>

                    <td>
                        {{ activiteit.soort.naam}}
                    </td>
                    <td>
                        {{ activiteit.users|length}}
                    </td>
                    <td title=\"bewerk de gegevens van deze activiteit\">


                        <a href=\"{{ path('update', {'id':activiteit.id}) }}\" >
                            <span class=\"glyphicon glyphicon-pencil\" style=\"color:red\"></span>
                        </a>
                    </td>
                    <td title=\"verwijder deze activiteit is definitief\">
                        <a href=\"{{ path('delete', {'id':activiteit.id}) }}\" >
                            <span class=\"glyphicon glyphicon-minus\" style=\"color:red\"></span>
                        </a>
                    </td>
                </tr>
            {% endfor %}
            <tr>
                <td colspan=\"6\">
                    <a href=\"{{ path('add') }}\">
                        <span class=\"glyphicon glyphicon-plus\" style=\"color:red\"></span>
                    </a>
                </td>

            </tr>

            </tbody>

        </table>


    </section>

{% endblock %}
", "medewerker/beheer.html.twig", "C:\\xampp\\htdocs\\karting4\\templates\\medewerker\\beheer.html.twig");
    }
}
