<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* medewerker/details.html.twig */
class __TwigTemplate_cd3a3b3a845da273bc86d3f6b3d9a2d3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'menu' => [$this, 'block_menu'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "medewerker.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "medewerker/details.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "medewerker/details.html.twig"));

        $this->parent = $this->loadTemplate("medewerker.html.twig", "medewerker/details.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_menu($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        // line 4
        echo "    <li><a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("activiteitenoverzicht");
        echo "\">home</a></li>
    <li><a href=\"";
        // line 5
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("beheer");
        echo "\"><span class=\"badge\">";
        echo twig_escape_filter($this->env, (isset($context["aantal"]) || array_key_exists("aantal", $context) ? $context["aantal"] : (function () { throw new RuntimeError('Variable "aantal" does not exist.', 5, $this->source); })()), "html", null, true);
        echo "</span>beheer</a></li>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 8
        echo "

    <section >
        <table class=\"table table-bordered\" style=\"table-layout: fixed\">
            <caption>Activiteit</caption>
            <tr >
                <td>soort</td>
                <td class=\"text-primary\">";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["activiteit"]) || array_key_exists("activiteit", $context) ? $context["activiteit"] : (function () { throw new RuntimeError('Variable "activiteit" does not exist.', 15, $this->source); })()), "soort", [], "any", false, false, false, 15), "naam", [], "any", false, false, false, 15), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <td>datum:</td>
                <td>";
        // line 19
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["activiteit"]) || array_key_exists("activiteit", $context) ? $context["activiteit"] : (function () { throw new RuntimeError('Variable "activiteit" does not exist.', 19, $this->source); })()), "datum", [], "any", false, false, false, 19), "d-m-Y"), "html", null, true);
        echo " </td>
            </tr>
            <tr >
                <td>tijd:</td>
                <td>";
        // line 23
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["activiteit"]) || array_key_exists("activiteit", $context) ? $context["activiteit"] : (function () { throw new RuntimeError('Variable "activiteit" does not exist.', 23, $this->source); })()), "tijd", [], "any", false, false, false, 23), "h:i"), "html", null, true);
        echo "</td>
            </tr>


        </table>
        ";
        // line 28
        if ((twig_length_filter($this->env, (isset($context["deelnemers"]) || array_key_exists("deelnemers", $context) ? $context["deelnemers"] : (function () { throw new RuntimeError('Variable "deelnemers" does not exist.', 28, $this->source); })())) > 0)) {
            // line 29
            echo "            <table class=\"table table-striped\" style=\"table-layout: fixed\">
                <caption>Dit zijn de deelnemers</caption>
                <thead>
                <tr>
                    <td>naam</td>
                    <td>adres</td>
                    <td>postcode</td>
                    <td>woonplaats</td>
                    <td>email</td>
                    <td>telefoon</td>
                </tr>
                </thead>
                <tbody>

                ";
            // line 43
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["deelnemers"]) || array_key_exists("deelnemers", $context) ? $context["deelnemers"] : (function () { throw new RuntimeError('Variable "deelnemers" does not exist.', 43, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["deelnemer"]) {
                // line 44
                echo "                <tr>

                    <td>";
                // line 46
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["deelnemer"], "naam", [], "any", false, false, false, 46), "html", null, true);
                echo "</td>
                    <td> ";
                // line 47
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["deelnemer"], "adres", [], "any", false, false, false, 47), "html", null, true);
                echo "</td>
                    <td> ";
                // line 48
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["deelnemer"], "postcode", [], "any", false, false, false, 48), "html", null, true);
                echo "</td>
                    <td>";
                // line 49
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["deelnemer"], "woonplaats", [], "any", false, false, false, 49), "html", null, true);
                echo "</td>
                    <td>";
                // line 50
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["deelnemer"], "email", [], "any", false, false, false, 50), "html", null, true);
                echo "</td>
                    <td>";
                // line 51
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["deelnemer"], "telefoon", [], "any", false, false, false, 51), "html", null, true);
                echo "</td>

                </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['deelnemer'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 55
            echo "
                </tbody>
            </table>
        ";
        } else {
            // line 59
            echo "             <p> geen deelnemers </p>
        ";
        }
        // line 61
        echo "
        <br  />
    </section>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "medewerker/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  195 => 61,  191 => 59,  185 => 55,  175 => 51,  171 => 50,  167 => 49,  163 => 48,  159 => 47,  155 => 46,  151 => 44,  147 => 43,  131 => 29,  129 => 28,  121 => 23,  114 => 19,  107 => 15,  98 => 8,  88 => 7,  74 => 5,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'medewerker.html.twig' %}

{% block menu %}
    <li><a href=\"{{ path('activiteitenoverzicht') }}\">home</a></li>
    <li><a href=\"{{ path('beheer') }}\"><span class=\"badge\">{{ aantal }}</span>beheer</a></li>
{% endblock %}
{% block content %}


    <section >
        <table class=\"table table-bordered\" style=\"table-layout: fixed\">
            <caption>Activiteit</caption>
            <tr >
                <td>soort</td>
                <td class=\"text-primary\">{{ activiteit.soort.naam}}</td>
            </tr>
            <tr>
                <td>datum:</td>
                <td>{{ activiteit.datum|date(\"d-m-Y\")}} </td>
            </tr>
            <tr >
                <td>tijd:</td>
                <td>{{ activiteit.tijd|date(\"h:i\")}}</td>
            </tr>


        </table>
        {%  if deelnemers|length > 0 %}
            <table class=\"table table-striped\" style=\"table-layout: fixed\">
                <caption>Dit zijn de deelnemers</caption>
                <thead>
                <tr>
                    <td>naam</td>
                    <td>adres</td>
                    <td>postcode</td>
                    <td>woonplaats</td>
                    <td>email</td>
                    <td>telefoon</td>
                </tr>
                </thead>
                <tbody>

                {% for deelnemer in deelnemers %}
                <tr>

                    <td>{{ deelnemer.naam}}</td>
                    <td> {{ deelnemer.adres}}</td>
                    <td> {{ deelnemer.postcode}}</td>
                    <td>{{ deelnemer.woonplaats}}</td>
                    <td>{{ deelnemer.email}}</td>
                    <td>{{ deelnemer.telefoon}}</td>

                </tr>
                {% endfor %}

                </tbody>
            </table>
        {% else %}
             <p> geen deelnemers </p>
        {% endif %}

        <br  />
    </section>

{% endblock %}
", "medewerker/details.html.twig", "C:\\xampp\\htdocs\\karting4\\templates\\medewerker\\details.html.twig");
    }
}
